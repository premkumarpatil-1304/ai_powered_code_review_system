export const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export type User = { id: string; email: string; created_at: string };
export type Project = { id: string; name: string; description?: string; created_at: string };
export type FileNode = { id: string; name: string; path: string; is_directory: boolean; extension?: string; language?: string; size?: number; children: FileNode[] };
export type Provider = { id: string; name: string; provider_type: string; base_url: string; model_name: string; is_default: boolean; has_api_key: boolean; created_at: string };
export type ReviewIssue = { title: string; severity: "critical" | "high" | "medium" | "low"; file_path: string; line_start: number; line_end: number; description: string; recommendation: string };
export type Review = { id: string; project_id: string; template_id?: string; provider_id?: string; scope: string; target_file_ids: string[]; status: "pending" | "completed" | "failed"; summary: string | null; issues: ReviewIssue[] | null; recommendations: string[] | null; error_message?: string | null; created_at: string };

export class ApiError extends Error { status: number; constructor(message: string, status: number) { super(message); this.status = status; } }

export async function api<T>(path: string, init: RequestInit = {}, token?: string): Promise<T> {
  const headers = new Headers(init.headers);
  if (!(init.body instanceof FormData)) headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const res = await fetch(`${API_BASE}${path}`, { ...init, headers });
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try { const body = await res.json(); message = body.detail || body.message || message; } catch {}
    if (res.status === 401 && typeof window !== "undefined") { localStorage.removeItem("review_token"); window.location.href = "/login"; }
    throw new ApiError(message, res.status);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}
